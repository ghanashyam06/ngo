import React from 'react';
import Layout from '../components/layout/Layout';
import OpportunityList from '../components/opportunities/OpportunityList';

const OpportunitiesPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-gray-100 min-h-screen">
        <OpportunityList />
      </div>
    </Layout>
  );
};

export default OpportunitiesPage;