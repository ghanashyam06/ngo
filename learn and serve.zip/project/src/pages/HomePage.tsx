import React from 'react';
import Layout from '../components/layout/Layout';
import Hero from '../components/home/Hero';
import FeaturedOpportunities from '../components/home/FeaturedOpportunities';
import HowItWorks from '../components/home/HowItWorks';
import ImpactStats from '../components/home/ImpactStats';
import Testimonials from '../components/home/Testimonials';
import CallToAction from '../components/home/CallToAction';

const HomePage: React.FC = () => {
  return (
    <Layout>
      <Hero />
      <FeaturedOpportunities />
      <HowItWorks />
      <ImpactStats />
      <Testimonials />
      <CallToAction />
    </Layout>
  );
};

export default HomePage;