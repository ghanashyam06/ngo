import React from 'react';
import { Navigate } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import StudentDashboard from '../components/dashboard/StudentDashboard';
import NGODashboard from '../components/dashboard/NGODashboard';
import InstitutionDashboard from '../components/dashboard/InstitutionDashboard';
import { useAuth } from '../context/AuthContext';

const DashboardPage: React.FC = () => {
  const { currentUser, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 flex justify-center items-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading your dashboard...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!currentUser) {
    return <Navigate to="/login" />;
  }

  const renderDashboard = () => {
    switch (currentUser.role) {
      case 'student':
        return <StudentDashboard />;
      case 'ngo':
        return <NGODashboard />;
      case 'institution':
        return <InstitutionDashboard />;
      default:
        return <Navigate to="/" />;
    }
  };

  return (
    <Layout>
      <div className="bg-gray-100 min-h-screen">
        {renderDashboard()}
      </div>
    </Layout>
  );
};

export default DashboardPage;