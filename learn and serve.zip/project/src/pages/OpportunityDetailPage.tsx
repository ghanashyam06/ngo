import React from 'react';
import Layout from '../components/layout/Layout';
import OpportunityDetail from '../components/opportunities/OpportunityDetail';

const OpportunityDetailPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-gray-100 min-h-screen">
        <OpportunityDetail />
      </div>
    </Layout>
  );
};

export default OpportunityDetailPage;