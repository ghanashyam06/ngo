import React from 'react';
import { Link, useParams } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import { CheckCircle, ArrowLeft, Home } from 'lucide-react';
import { useOpportunities } from '../context/OpportunityContext';

const ApplicationSuccessPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getOpportunityById } = useOpportunities();
  
  const opportunity = getOpportunityById(id || '');

  return (
    <Layout>
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="flex justify-center mb-6">
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle size={48} className="text-green-600" />
              </div>
            </div>
            
            <h1 className="text-3xl font-bold text-gray-800 mb-4">Application Submitted!</h1>
            
            <p className="text-gray-600 mb-8">
              Your application for{' '}
              <span className="font-semibold">{opportunity?.title || 'this opportunity'}</span>{' '}
              at{' '}
              <span className="font-semibold">{opportunity?.ngoName || 'the NGO'}</span>{' '}
              has been successfully submitted. You will be notified when the NGO reviews your application.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link
                to={`/opportunities/${id}`}
                className="flex items-center justify-center px-6 py-3 bg-white border border-primary-600 text-primary-600 rounded-md hover:bg-primary-50 transition duration-300"
              >
                <ArrowLeft size={20} className="mr-2" />
                Back to Opportunity
              </Link>
              
              <Link
                to="/dashboard"
                className="flex items-center justify-center px-6 py-3 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition duration-300"
              >
                Go to Dashboard
                <Home size={20} className="ml-2" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ApplicationSuccessPage;