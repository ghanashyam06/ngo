import React from 'react';
import Layout from '../components/layout/Layout';
import DirectoryList from '../components/directory/DirectoryList';

const DirectoryPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-gray-100 min-h-screen">
        <DirectoryList />
      </div>
    </Layout>
  );
};

export default DirectoryPage;