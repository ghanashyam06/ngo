import React from 'react';
import Layout from '../components/layout/Layout';
import OpportunityApplication from '../components/opportunities/OpportunityApplication';

const OpportunityApplicationPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-gray-100 min-h-screen">
        <OpportunityApplication />
      </div>
    </Layout>
  );
};

export default OpportunityApplicationPage;