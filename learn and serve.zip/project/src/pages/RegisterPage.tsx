import React from 'react';
import Layout from '../components/layout/Layout';
import Register from '../components/auth/Register';

const RegisterPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-gray-100 min-h-screen">
        <Register />
      </div>
    </Layout>
  );
};

export default RegisterPage;