import React, { createContext, useContext, useState } from 'react';
import { Opportunity, Application } from '../types';
import { mockOpportunities } from '../data/mockData';

interface OpportunityContextType {
  opportunities: Opportunity[];
  applications: Application[];
  addOpportunity: (opportunity: Omit<Opportunity, 'id' | 'createdAt' | 'applicants'>) => void;
  applyToOpportunity: (opportunityId: string, studentId: string, studentName: string, duration: string, preferredLocation: string) => void;
  getOpportunityById: (id: string) => Opportunity | undefined;
  getApplicationsByStudentId: (studentId: string) => Application[];
  getApplicationsByOpportunityId: (opportunityId: string) => Application[];
}

const OpportunityContext = createContext<OpportunityContextType | undefined>(undefined);

export const useOpportunities = () => {
  const context = useContext(OpportunityContext);
  if (context === undefined) {
    throw new Error('useOpportunities must be used within an OpportunityProvider');
  }
  return context;
};

export const OpportunityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [opportunities, setOpportunities] = useState<Opportunity[]>(mockOpportunities);
  const [applications, setApplications] = useState<Application[]>([]);

  const addOpportunity = (opportunityData: Omit<Opportunity, 'id' | 'createdAt' | 'applicants'>) => {
    const newOpportunity: Opportunity = {
      ...opportunityData,
      id: `opp-${Date.now()}`,
      createdAt: new Date().toISOString(),
      applicants: [],
    };
    setOpportunities([newOpportunity, ...opportunities]);
  };

  const applyToOpportunity = (opportunityId: string, studentId: string, studentName: string, duration: string, preferredLocation: string) => {
    const newApplication: Application = {
      id: `app-${Date.now()}`,
      opportunityId,
      studentId,
      studentName,
      status: 'pending',
      createdAt: new Date().toISOString(),
      duration,
      preferredLocation,
    };
    setApplications([...applications, newApplication]);
    
    // Update the opportunity with the new applicant
    setOpportunities(opportunities.map(opp => {
      if (opp.id === opportunityId) {
        return {
          ...opp,
          applicants: [...(opp.applicants || []), studentId],
        };
      }
      return opp;
    }));
  };

  const getOpportunityById = (id: string) => {
    return opportunities.find(opp => opp.id === id);
  };

  const getApplicationsByStudentId = (studentId: string) => {
    return applications.filter(app => app.studentId === studentId);
  };

  const getApplicationsByOpportunityId = (opportunityId: string) => {
    return applications.filter(app => app.opportunityId === opportunityId);
  };

  return (
    <OpportunityContext.Provider value={{
      opportunities,
      applications,
      addOpportunity,
      applyToOpportunity,
      getOpportunityById,
      getApplicationsByStudentId,
      getApplicationsByOpportunityId,
    }}>
      {children}
    </OpportunityContext.Provider>
  );
};