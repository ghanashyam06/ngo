import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Student, NGO, Institution } from '../types';
import { mockStudents, mockNGOs, mockInstitutions } from '../data/mockData';

interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  login: (email: string, password: string, role: 'student' | 'ngo' | 'institution') => Promise<void>;
  logout: () => void;
  register: (userData: Partial<User>, password: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user in localStorage
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string, role: 'student' | 'ngo' | 'institution') => {
    setIsLoading(true);
    try {
      // In a real app, this would be an API call
      let user: User | undefined;

      if (role === 'student') {
        user = mockStudents.find(s => s.email === email);
      } else if (role === 'ngo') {
        user = mockNGOs.find(n => n.email === email);
      } else if (role === 'institution') {
        user = mockInstitutions.find(i => i.email === email);
      }

      if (!user) {
        throw new Error('Invalid email or password');
      }

      // In a real app, you would verify the password here
      setCurrentUser(user);
      localStorage.setItem('currentUser', JSON.stringify(user));
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const register = async (userData: Partial<User>, password: string) => {
    setIsLoading(true);
    try {
      // In a real app, this would be an API call
      // For now, we'll just simulate a successful registration
      const newUser = {
        ...userData,
        id: `new-${Date.now()}`,
      } as User;

      setCurrentUser(newUser);
      localStorage.setItem('currentUser', JSON.stringify(newUser));
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ currentUser, isLoading, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};