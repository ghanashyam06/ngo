import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { LogIn, User, Building, Users } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

type UserRole = 'student' | 'ngo' | 'institution';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  
  // Get role from URL query params
  const params = new URLSearchParams(location.search);
  const initialRole = (params.get('role') as UserRole) || 'student';
  
  const [role, setRole] = useState<UserRole>(initialRole);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    try {
      await login(email, password, role);
      navigate('/dashboard');
    } catch (err) {
      setError('Invalid email or password');
      setIsLoading(false);
    }
  };

  const getRoleIcon = () => {
    switch (role) {
      case 'student':
        return <User className="h-6 w-6 mr-2" />;
      case 'ngo':
        return <Building className="h-6 w-6 mr-2" />;
      case 'institution':
        return <Users className="h-6 w-6 mr-2" />;
      default:
        return null;
    }
  };

  // Sample credentials for easy login in the demo
  const sampleCredentials = {
    student: {
      email: 'alex.j@innovation.edu',
      password: 'password',
    },
    ngo: {
      email: 'contact@greenearthfoundation.org',
      password: 'password',
    },
    institution: {
      email: 'admin@innovation.edu',
      password: 'password',
    },
  };

  const handleAutoFill = () => {
    setEmail(sampleCredentials[role].email);
    setPassword(sampleCredentials[role].password);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome Back</h1>
          <p className="text-gray-600">Sign in to continue to your account</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8">
          {/* Role Selector */}
          <div className="flex mb-6">
            <button
              type="button"
              className={`flex-1 flex items-center justify-center py-2 border-b-2 transition-colors ${
                role === 'student'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-gray-200 text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setRole('student')}
            >
              <User className="h-5 w-5 mr-1" />
              <span>Student</span>
            </button>
            <button
              type="button"
              className={`flex-1 flex items-center justify-center py-2 border-b-2 transition-colors ${
                role === 'ngo'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-gray-200 text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setRole('ngo')}
            >
              <Building className="h-5 w-5 mr-1" />
              <span>NGO</span>
            </button>
            <button
              type="button"
              className={`flex-1 flex items-center justify-center py-2 border-b-2 transition-colors ${
                role === 'institution'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-gray-200 text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setRole('institution')}
            >
              <Users className="h-5 w-5 mr-1" />
              <span>Institution</span>
            </button>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit}>
            {error && (
              <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
                {error}
              </div>
            )}

            <div className="mb-4">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>

            <div className="mb-6">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>

            <div className="mb-6 text-center">
              <button
                type="button"
                onClick={handleAutoFill}
                className="text-primary-600 hover:text-primary-700 text-sm"
              >
                Use demo credentials for {role}
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-md transition duration-300 flex items-center justify-center"
            >
              {isLoading ? (
                <span>Signing in...</span>
              ) : (
                <>
                  <LogIn className="h-5 w-5 mr-2" />
                  <span>Sign In</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Don't have an account?{' '}
              <Link to={`/register?role=${role}`} className="text-primary-600 hover:text-primary-700 font-medium">
                Register now
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;