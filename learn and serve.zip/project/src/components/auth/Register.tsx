import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { UserPlus, User, Building, Users } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { mockInstitutions } from '../../data/mockData';

type UserRole = 'student' | 'ngo' | 'institution';

const Register: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { register } = useAuth();
  
  // Get role from URL query params
  const params = new URLSearchParams(location.search);
  const initialRole = (params.get('role') as UserRole) || 'student';
  
  const [role, setRole] = useState<UserRole>(initialRole);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    institution: '',
    phoneNumber: '',
    location: '',
    description: '',
    website: '',
    preferences: [] as string[],
  });
  
  const [errors, setErrors] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    institution: '',
    phoneNumber: '',
    location: '',
    description: '',
  });
  
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    // Clear error when field is edited
    if (errors[name as keyof typeof errors]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };

  const handlePreferenceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    if (checked) {
      setFormData({
        ...formData,
        preferences: [...formData.preferences, value],
      });
    } else {
      setFormData({
        ...formData,
        preferences: formData.preferences.filter(pref => pref !== value),
      });
    }
  };

  const validate = () => {
    const newErrors = {
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      institution: '',
      phoneNumber: '',
      location: '',
      description: '',
    };
    let isValid = true;

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
      isValid = false;
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
      isValid = false;
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
      isValid = false;
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
      isValid = false;
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
      isValid = false;
    }

    if (role === 'student' && !formData.institution) {
      newErrors.institution = 'Educational institution is required';
      isValid = false;
    }

    if (role !== 'student' && !formData.description.trim()) {
      newErrors.description = 'Description is required';
      isValid = false;
    }

    if (role !== 'student' && !formData.location.trim()) {
      newErrors.location = 'Location is required';
      isValid = false;
    }

    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = 'Phone number is required';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) {
      return;
    }

    setIsLoading(true);
    
    try {
      // Create user object based on role
      const userData = {
        name: formData.name,
        email: formData.email,
        role,
        phoneNumber: formData.phoneNumber,
      };

      if (role === 'student') {
        Object.assign(userData, {
          institution: formData.institution,
          preferences: formData.preferences,
        });
      } else {
        Object.assign(userData, {
          description: formData.description,
          location: formData.location,
          website: formData.website,
        });
      }

      await register(userData, formData.password);
      navigate('/dashboard');
    } catch (err) {
      console.error('Registration error:', err);
      setIsLoading(false);
    }
  };

  const commonPreferences = [
    'Environmental', 'Education', 'Healthcare', 'Technology', 
    'Social Work', 'Leadership', 'Research', 'Communication'
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Create an Account</h1>
          <p className="text-gray-600">Join Learn & Serve today and start making a difference</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8">
          {/* Role Selector */}
          <div className="flex mb-6">
            <button
              type="button"
              className={`flex-1 flex items-center justify-center py-2 border-b-2 transition-colors ${
                role === 'student'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-gray-200 text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setRole('student')}
            >
              <User className="h-5 w-5 mr-1" />
              <span>Student</span>
            </button>
            <button
              type="button"
              className={`flex-1 flex items-center justify-center py-2 border-b-2 transition-colors ${
                role === 'ngo'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-gray-200 text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setRole('ngo')}
            >
              <Building className="h-5 w-5 mr-1" />
              <span>NGO</span>
            </button>
            <button
              type="button"
              className={`flex-1 flex items-center justify-center py-2 border-b-2 transition-colors ${
                role === 'institution'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-gray-200 text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setRole('institution')}
            >
              <Users className="h-5 w-5 mr-1" />
              <span>Institution</span>
            </button>
          </div>

          {/* Registration Form */}
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Name */}
              <div className="md:col-span-2">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  {role === 'student' ? 'Full Name' : role === 'ngo' ? 'NGO Name' : 'Institution Name'}*
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name}</p>}
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address*
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.email ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
              </div>

              {/* Phone */}
              <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number*
                </label>
                <input
                  type="tel"
                  id="phoneNumber"
                  name="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.phoneNumber ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.phoneNumber && <p className="mt-1 text-sm text-red-600">{errors.phoneNumber}</p>}
              </div>

              {/* Password */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password*
                </label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.password ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password}</p>}
              </div>

              {/* Confirm Password */}
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password*
                </label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.confirmPassword ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.confirmPassword && <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>}
              </div>

              {/* Institution (only for students) */}
              {role === 'student' && (
                <div className="md:col-span-2">
                  <label htmlFor="institution" className="block text-sm font-medium text-gray-700 mb-1">
                    Educational Institution*
                  </label>
                  <select
                    id="institution"
                    name="institution"
                    value={formData.institution}
                    onChange={handleChange}
                    className={`block w-full px-3 py-2 border ${errors.institution ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  >
                    <option value="">Select your institution</option>
                    {mockInstitutions.map(inst => (
                      <option key={inst.id} value={inst.name}>{inst.name}</option>
                    ))}
                  </select>
                  {errors.institution && <p className="mt-1 text-sm text-red-600">{errors.institution}</p>}
                </div>
              )}

              {/* Location (only for NGOs and institutions) */}
              {role !== 'student' && (
                <div className="md:col-span-2">
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    Location*
                  </label>
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    placeholder="City, State/Province, Country"
                    className={`block w-full px-3 py-2 border ${errors.location ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  />
                  {errors.location && <p className="mt-1 text-sm text-red-600">{errors.location}</p>}
                </div>
              )}

              {/* Website (only for NGOs and institutions) */}
              {role !== 'student' && (
                <div className="md:col-span-2">
                  <label htmlFor="website" className="block text-sm font-medium text-gray-700 mb-1">
                    Website (Optional)
                  </label>
                  <input
                    type="url"
                    id="website"
                    name="website"
                    value={formData.website}
                    onChange={handleChange}
                    placeholder="https://www.example.org"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
              )}

              {/* Description (only for NGOs and institutions) */}
              {role !== 'student' && (
                <div className="md:col-span-2">
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description*
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={4}
                    value={formData.description}
                    onChange={handleChange}
                    placeholder={`Briefly describe your ${role === 'ngo' ? 'organization' : 'institution'} and its mission`}
                    className={`block w-full px-3 py-2 border ${errors.description ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  />
                  {errors.description && <p className="mt-1 text-sm text-red-600">{errors.description}</p>}
                </div>
              )}

              {/* Preferences (only for students) */}
              {role === 'student' && (
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Areas of Interest (Optional)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {commonPreferences.map((preference, index) => (
                      <div key={index} className="flex items-center">
                        <input
                          type="checkbox"
                          id={`preference-${index}`}
                          value={preference}
                          checked={formData.preferences.includes(preference)}
                          onChange={handlePreferenceChange}
                          className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        />
                        <label htmlFor={`preference-${index}`} className="ml-2 text-sm text-gray-700">
                          {preference}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="mt-8">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-md transition duration-300 flex items-center justify-center"
              >
                {isLoading ? (
                  <span>Creating account...</span>
                ) : (
                  <>
                    <UserPlus className="h-5 w-5 mr-2" />
                    <span>Create Account</span>
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Already have an account?{' '}
              <Link to={`/login?role=${role}`} className="text-primary-600 hover:text-primary-700 font-medium">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;