import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';
import { ngoWorkerQuotes } from '../../data/mockData';

const Footer: React.FC = () => {
  const [currentQuote, setCurrentQuote] = useState(ngoWorkerQuotes[0]);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * ngoWorkerQuotes.length);
      setCurrentQuote(ngoWorkerQuotes[randomIndex]);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  return (
    <footer className="bg-gray-800 text-white">
      {/* Quote Section */}
      <div className="bg-primary-700 py-6">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="min-h-[120px] flex items-center justify-center">
              <div className="transition-opacity duration-500">
                <p className="text-lg italic mb-2">"{currentQuote.text}"</p>
                <p className="font-semibold">— {currentQuote.author}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <h3 className="text-xl font-bold mb-4">About Learn & Serve</h3>
            <p className="text-gray-300 mb-4">
              Connecting NGOs, educational institutions, and students across India to create meaningful social impact through internships and volunteering opportunities.
            </p>
            <div className="flex items-center">
              <span className="text-gray-300">Made with</span>
              <Heart size={16} className="mx-1 text-accent-500" />
              <span className="text-gray-300">for a better India</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition duration-300">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/opportunities" className="text-gray-300 hover:text-white transition duration-300">
                  Opportunities
                </Link>
              </li>
              <li>
                <Link to="/directory" className="text-gray-300 hover:text-white transition duration-300">
                  Directory
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-white transition duration-300">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* For Users */}
          <div>
            <h3 className="text-xl font-bold mb-4">For Users</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/register?role=student" className="text-gray-300 hover:text-white transition duration-300">
                  Student Sign Up
                </Link>
              </li>
              <li>
                <Link to="/register?role=ngo" className="text-gray-300 hover:text-white transition duration-300">
                  NGO Registration
                </Link>
              </li>
              <li>
                <Link to="/register?role=institution" className="text-gray-300 hover:text-white transition duration-300">
                  Institution Registration
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-300 hover:text-white transition duration-300">
                  Login
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Mail size={20} className="mr-2 mt-1 text-gray-400" />
                <span className="text-gray-300">learnandserve2025@gmail.com</span>
              </li>
              <li className="flex items-start">
                <Phone size={20} className="mr-2 mt-1 text-gray-400" />
                <span className="text-gray-300">+91 8341533904</span>
              </li>
              <li className="flex items-start">
                <MapPin size={20} className="mr-2 mt-1 text-gray-400" />
                <span className="text-gray-300">
                  Dundigal, Hyderabad<br />
                  Telangana, 500043<br />
                  India
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            &copy; {new Date().getFullYear()} Learn & Serve. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;