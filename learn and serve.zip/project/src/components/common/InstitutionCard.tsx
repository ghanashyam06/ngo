import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Globe, Phone } from 'lucide-react';
import { Institution } from '../../types';

interface InstitutionCardProps {
  institution: Institution;
}

const InstitutionCard: React.FC<InstitutionCardProps> = ({ institution }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{institution.name}</h3>
        <p className="text-gray-600 mb-4">{institution.description}</p>

        <div className="flex flex-col space-y-2 mb-4">
          <div className="flex items-center text-gray-600">
            <MapPin size={16} className="mr-2 text-primary-500" />
            <span>{institution.location}</span>
          </div>
          {institution.website && (
            <div className="flex items-center text-gray-600">
              <Globe size={16} className="mr-2 text-primary-500" />
              <a 
                href={institution.website.startsWith('http') ? institution.website : `https://${institution.website}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary-600 hover:underline"
              >
                {institution.website}
              </a>
            </div>
          )}
          <div className="flex items-center text-gray-600">
            <Phone size={16} className="mr-2 text-primary-500" />
            <span>{institution.phoneNumber}</span>
          </div>
        </div>

        <Link 
          to={`/directory/institutions/${institution.id}`} 
          className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-md transition duration-300 inline-block"
        >
          View Profile
        </Link>
      </div>
    </div>
  );
};

export default InstitutionCard;