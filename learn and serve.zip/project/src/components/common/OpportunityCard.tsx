import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, Clock } from 'lucide-react';
import { Opportunity } from '../../types';

interface OpportunityCardProps {
  opportunity: Opportunity;
  showApplyButton?: boolean;
}

const OpportunityCard: React.FC<OpportunityCardProps> = ({ opportunity, showApplyButton = true }) => {
  const truncateDescription = (text: string, maxLength: number = 120) => {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength) + '...';
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{opportunity.title}</h3>
        <p className="text-secondary-600 font-medium mb-2">{opportunity.ngoName}</p>

        <p className="text-gray-600 mb-4">{truncateDescription(opportunity.description)}</p>

        <div className="flex flex-col space-y-2 mb-4">
          <div className="flex items-center text-gray-600">
            <MapPin size={16} className="mr-2 text-primary-500" />
            <span>{opportunity.location}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Clock size={16} className="mr-2 text-primary-500" />
            <span>{opportunity.duration}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Calendar size={16} className="mr-2 text-primary-500" />
            <span>Deadline: {new Date(opportunity.deadline).toLocaleDateString()}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {opportunity.skills.slice(0, 3).map((skill, index) => (
            <span 
              key={index} 
              className="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full"
            >
              {skill}
            </span>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row sm:justify-between gap-3">
          <Link 
            to={`/opportunities/${opportunity.id}`} 
            className="text-primary-600 hover:text-primary-700 font-medium text-center sm:text-left"
          >
            View Details
          </Link>
          {showApplyButton && (
            <Link 
              to={`/opportunities/${opportunity.id}/apply`} 
              className="bg-accent-500 hover:bg-accent-600 text-white px-4 py-2 rounded-md transition duration-300 text-center"
            >
              Apply Now
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default OpportunityCard;