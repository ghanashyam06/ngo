import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Globe, Phone } from 'lucide-react';
import { NGO } from '../../types';

interface NGOCardProps {
  ngo: NGO;
}

const NGOCard: React.FC<NGOCardProps> = ({ ngo }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="h-40 bg-gray-200 overflow-hidden">
        {ngo.profilePicture ? (
          <img 
            src={ngo.profilePicture} 
            alt={ngo.name} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary-100">
            <span className="text-3xl font-bold text-primary-600">{ngo.name.charAt(0)}</span>
          </div>
        )}
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{ngo.name}</h3>
        <p className="text-gray-600 mb-4 line-clamp-2">{ngo.description}</p>

        <div className="flex flex-col space-y-2 mb-4">
          <div className="flex items-center text-gray-600">
            <MapPin size={16} className="mr-2 text-primary-500" />
            <span>{ngo.location}</span>
          </div>
          {ngo.website && (
            <div className="flex items-center text-gray-600">
              <Globe size={16} className="mr-2 text-primary-500" />
              <a 
                href={ngo.website.startsWith('http') ? ngo.website : `https://${ngo.website}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary-600 hover:underline"
              >
                {ngo.website}
              </a>
            </div>
          )}
          <div className="flex items-center text-gray-600">
            <Phone size={16} className="mr-2 text-primary-500" />
            <span>{ngo.phoneNumber}</span>
          </div>
        </div>

        <Link 
          to={`/directory/ngos/${ngo.id}`} 
          className="bg-secondary-500 hover:bg-secondary-600 text-white px-4 py-2 rounded-md transition duration-300 inline-block"
        >
          View Profile
        </Link>
      </div>
    </div>
  );
};

export default NGOCard;