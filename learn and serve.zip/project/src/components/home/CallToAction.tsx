import React from 'react';
import { Link } from 'react-router-dom';

const CallToAction: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-primary-600 to-primary-800 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Make a Difference?</h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Join Learn & Serve today and be part of a community dedicated to creating positive social impact through meaningful connections and opportunities.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/register?role=student"
              className="bg-white text-primary-600 hover:bg-primary-50 px-6 py-3 rounded-md font-medium text-lg transition duration-300"
            >
              Sign Up as Student
            </Link>
            <Link
              to="/opportunities"
              className="bg-accent-500 hover:bg-accent-600 text-white px-6 py-3 rounded-md font-medium text-lg transition duration-300"
            >
              Browse Opportunities
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;