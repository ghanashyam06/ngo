import React from 'react';
import { UserPlus, Search, FileText, Award } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <UserPlus size={32} />,
      title: 'Create an Account',
      description: 'Sign up as a student, NGO, or educational institution to access the platform.',
      color: 'bg-primary-600',
      iconBg: 'bg-primary-100 text-primary-600',
    },
    {
      icon: <Search size={32} />,
      title: 'Find Opportunities',
      description: 'Browse through available internships and volunteer positions based on your interests.',
      color: 'bg-secondary-600',
      iconBg: 'bg-secondary-100 text-secondary-600',
    },
    {
      icon: <FileText size={32} />,
      title: 'Apply & Connect',
      description: 'Submit applications to NGOs and get connected with meaningful projects.',
      color: 'bg-accent-500',
      iconBg: 'bg-accent-100 text-accent-600',
    },
    {
      icon: <Award size={32} />,
      title: 'Track & Get Rewarded',
      description: 'Monitor your progress, earn certificates, and showcase your impact.',
      color: 'bg-gray-700',
      iconBg: 'bg-gray-200 text-gray-700',
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-4">How It Works</h2>
        <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
          Learn & Serve makes it easy to connect, engage, and create social impact through a simple process.
        </p>

        <div className="relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-gray-200 -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
            {steps.map((step, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className={`${step.iconBg} w-20 h-20 rounded-full flex items-center justify-center mb-4`}>
                  {step.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">{step.title}</h3>
                <p className="text-gray-600 text-center">{step.description}</p>
                <div className={`${step.color} h-2 w-16 rounded-full mt-4`}></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;