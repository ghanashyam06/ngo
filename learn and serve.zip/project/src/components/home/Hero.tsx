import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Users, Award } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-primary-600 to-primary-800 text-white">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            Connect, Learn & Make a Difference
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-primary-100">
            Bridging the gap between students, educational institutions, and NGOs
            to create meaningful social impact through internships and volunteering.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/register?role=student"
              className="bg-white text-primary-600 hover:bg-primary-50 px-6 py-3 rounded-md font-medium text-lg transition duration-300"
            >
              Join as Student
            </Link>
            <Link
              to="/register?role=ngo"
              className="bg-accent-500 hover:bg-accent-600 text-white px-6 py-3 rounded-md font-medium text-lg transition duration-300"
            >
              Register NGO
            </Link>
          </div>
        </div>
      </div>

      {/* Feature Cards */}
      <div className="container mx-auto px-4 pb-16 md:pb-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto -mt-8">
          <div className="bg-white rounded-lg shadow-lg p-6 text-center transform transition duration-500 hover:-translate-y-2">
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search size={32} />
            </div>
            <h3 className="text-gray-800 text-xl font-bold mb-2">Find Opportunities</h3>
            <p className="text-gray-600">
              Discover meaningful internships and volunteer positions aligned with your interests and skills.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg p-6 text-center transform transition duration-500 hover:-translate-y-2">
            <div className="bg-secondary-100 text-secondary-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users size={32} />
            </div>
            <h3 className="text-gray-800 text-xl font-bold mb-2">Connect & Collaborate</h3>
            <p className="text-gray-600">
              Build relationships with NGOs and educational institutions to create lasting social impact.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg p-6 text-center transform transition duration-500 hover:-translate-y-2">
            <div className="bg-accent-100 text-accent-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award size={32} />
            </div>
            <h3 className="text-gray-800 text-xl font-bold mb-2">Track Your Impact</h3>
            <p className="text-gray-600">
              Monitor your progress, earn rewards, and showcase your social contribution achievements.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;