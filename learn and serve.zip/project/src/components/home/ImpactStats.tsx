import React from 'react';
import { Users, Building, BookOpen, Award } from 'lucide-react';

const ImpactStats: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Our Impact</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-primary-50 rounded-lg p-6 text-center transform transition duration-500 hover:shadow-lg">
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users size={28} />
            </div>
            <div className="text-4xl font-bold text-primary-600 mb-2">500+</div>
            <p className="text-gray-700 font-medium">Students Engaged</p>
          </div>
          
          <div className="bg-secondary-50 rounded-lg p-6 text-center transform transition duration-500 hover:shadow-lg">
            <div className="bg-secondary-100 text-secondary-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Building size={28} />
            </div>
            <div className="text-4xl font-bold text-secondary-600 mb-2">75+</div>
            <p className="text-gray-700 font-medium">NGO Partners</p>
          </div>
          
          <div className="bg-accent-50 rounded-lg p-6 text-center transform transition duration-500 hover:shadow-lg">
            <div className="bg-accent-100 text-accent-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen size={28} />
            </div>
            <div className="text-4xl font-bold text-accent-600 mb-2">40+</div>
            <p className="text-gray-700 font-medium">Educational Institutions</p>
          </div>
          
          <div className="bg-gray-100 rounded-lg p-6 text-center transform transition duration-500 hover:shadow-lg">
            <div className="bg-gray-200 text-gray-700 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award size={28} />
            </div>
            <div className="text-4xl font-bold text-gray-700 mb-2">1,200+</div>
            <p className="text-gray-700 font-medium">Internships Completed</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImpactStats;