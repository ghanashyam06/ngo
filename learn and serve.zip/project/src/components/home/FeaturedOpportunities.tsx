import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import OpportunityCard from '../common/OpportunityCard';
import { useOpportunities } from '../../context/OpportunityContext';

const FeaturedOpportunities: React.FC = () => {
  const { opportunities } = useOpportunities();
  
  // Get the most recent opportunities
  const featuredOpportunities = opportunities
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3);

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800">Featured Opportunities</h2>
          <Link 
            to="/opportunities" 
            className="flex items-center text-primary-600 hover:text-primary-700 font-medium"
          >
            View All <ChevronRight size={20} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredOpportunities.map((opportunity) => (
            <OpportunityCard 
              key={opportunity.id} 
              opportunity={opportunity}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedOpportunities;