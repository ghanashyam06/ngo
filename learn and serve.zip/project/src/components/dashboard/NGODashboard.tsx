import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Briefcase, 
  PlusCircle, 
  Building, 
  ChevronRight 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { NGO } from '../../types';
import { useOpportunities } from '../../context/OpportunityContext';
import { mockInstitutions, mockStudents } from '../../data/mockData';

const NGODashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const ngo = currentUser as NGO;
  const { opportunities, applications } = useOpportunities();
  
  // Filter opportunities posted by this NGO
  const ngoOpportunities = opportunities.filter(opp => opp.ngoId === ngo.id);
  
  // Get applications for this NGO's opportunities
  const ngoApplications = applications.filter(app => 
    ngoOpportunities.some(opp => opp.id === app.opportunityId)
  );

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Welcome, {ngo.name}!</h1>
        <p className="text-gray-600">Manage your opportunities and connect with talented students across India.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Stats Cards */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Opportunities</p>
              <h3 className="text-3xl font-bold text-gray-800">{ngoOpportunities.length}</h3>
            </div>
            <div className="bg-primary-100 p-3 rounded-full">
              <Briefcase className="text-primary-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Applications</p>
              <h3 className="text-3xl font-bold text-gray-800">{ngoApplications.length}</h3>
            </div>
            <div className="bg-secondary-100 p-3 rounded-full">
              <Users className="text-secondary-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Institutions</p>
              <h3 className="text-3xl font-bold text-gray-800">{mockInstitutions.length}</h3>
            </div>
            <div className="bg-accent-100 p-3 rounded-full">
              <Building className="text-accent-600" size={24} />
            </div>
          </div>
        </div>

        <Link 
          to="/opportunities/new" 
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition duration-300 flex flex-col justify-center items-center border-2 border-dashed border-gray-300"
        >
          <PlusCircle size={32} className="text-primary-600 mb-2" />
          <p className="text-primary-600 font-medium">Post New Opportunity</p>
        </Link>
      </div>

      {/* Posted Opportunities */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Your Posted Opportunities</h2>
          <Link to="/opportunities/manage" className="text-primary-600 hover:text-primary-700 flex items-center">
            Manage All <ChevronRight size={16} />
          </Link>
        </div>

        {ngoOpportunities.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2 text-gray-600">Title</th>
                  <th className="text-left py-3 px-2 text-gray-600">Location</th>
                  <th className="text-left py-3 px-2 text-gray-600">Deadline</th>
                  <th className="text-left py-3 px-2 text-gray-600">Applications</th>
                  <th className="text-left py-3 px-2 text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {ngoOpportunities.slice(0, 5).map((opportunity) => {
                  const applicationCount = opportunity.applicants?.length || 0;
                  
                  return (
                    <tr key={opportunity.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-2">
                        <Link to={`/opportunities/${opportunity.id}`} className="text-primary-600 hover:text-primary-700">
                          {opportunity.title}
                        </Link>
                      </td>
                      <td className="py-3 px-2 text-gray-700">{opportunity.location}</td>
                      <td className="py-3 px-2 text-gray-700">{new Date(opportunity.deadline).toLocaleDateString()}</td>
                      <td className="py-3 px-2 text-gray-700">{applicationCount}</td>
                      <td className="py-3 px-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          opportunity.status === 'open' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {opportunity.status.charAt(0).toUpperCase() + opportunity.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600 mb-4">You haven't posted any opportunities yet.</p>
            <Link 
              to="/opportunities/new" 
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md transition duration-300"
            >
              Post Your First Opportunity
            </Link>
          </div>
        )}
      </div>

      {/* Recent Applications */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Recent Applications</h2>
          <Link to="/applications" className="text-primary-600 hover:text-primary-700 flex items-center">
            View All <ChevronRight size={16} />
          </Link>
        </div>

        {ngoApplications.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2 text-gray-600">Student</th>
                  <th className="text-left py-3 px-2 text-gray-600">Opportunity</th>
                  <th className="text-left py-3 px-2 text-gray-600">Institution</th>
                  <th className="text-left py-3 px-2 text-gray-600">Applied On</th>
                  <th className="text-left py-3 px-2 text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {ngoApplications.slice(0, 5).map((application) => {
                  const opportunity = opportunities.find(opp => opp.id === application.opportunityId);
                  const student = mockStudents.find(s => s.id === application.studentId);
                  
                  return (
                    <tr key={application.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-2 text-gray-700">{student?.name || 'Unknown Student'}</td>
                      <td className="py-3 px-2">
                        <Link to={`/opportunities/${application.opportunityId}`} className="text-primary-600 hover:text-primary-700">
                          {opportunity?.title || 'Unknown Opportunity'}
                        </Link>
                      </td>
                      <td className="py-3 px-2 text-gray-700">{student?.institution || 'Unknown Institution'}</td>
                      <td className="py-3 px-2 text-gray-700">{new Date(application.createdAt).toLocaleDateString()}</td>
                      <td className="py-3 px-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          application.status === 'accepted' ? 'bg-green-100 text-green-800' :
                          application.status === 'rejected' ? 'bg-red-100 text-red-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600">No applications received yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NGODashboard;