import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Building, 
  GraduationCap, 
  BarChart2, 
  ChevronRight 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Institution } from '../../types';
import { mockNGOs, mockStudents } from '../../data/mockData';

const InstitutionDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const institution = currentUser as Institution;
  
  // Filter students from this institution
  const institutionStudents = mockStudents.filter(student => 
    student.institution === institution.name
  );

  // Mock data for the participation graph
  const participationData = [
    { month: 'Jan', count: 12 },
    { month: 'Feb', count: 15 },
    { month: 'Mar', count: 18 },
    { month: 'Apr', count: 25 },
    { month: 'May', count: 22 },
    { month: 'Jun', count: 30 },
  ];

  const maxParticipation = Math.max(...participationData.map(d => d.count));

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Welcome, {institution.name}!</h1>
        <p className="text-gray-600">Monitor your students' engagement and connect with NGOs.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Stats Cards */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Students</p>
              <h3 className="text-3xl font-bold text-gray-800">{institutionStudents.length}</h3>
            </div>
            <div className="bg-primary-100 p-3 rounded-full">
              <GraduationCap className="text-primary-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Partner NGOs</p>
              <h3 className="text-3xl font-bold text-gray-800">{mockNGOs.length}</h3>
            </div>
            <div className="bg-secondary-100 p-3 rounded-full">
              <Building className="text-secondary-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Active Internships</p>
              <h3 className="text-3xl font-bold text-gray-800">28</h3>
            </div>
            <div className="bg-accent-100 p-3 rounded-full">
              <Users className="text-accent-600" size={24} />
            </div>
          </div>
        </div>
      </div>

      {/* Student Participation Graph */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">Student Participation</h2>
          <div className="flex space-x-2">
            <select className="border rounded-md px-3 py-1 text-sm text-gray-700">
              <option>Last 6 Months</option>
              <option>Last Year</option>
              <option>All Time</option>
            </select>
          </div>
        </div>

        <div className="h-64">
          <div className="flex h-full">
            <div className="flex flex-col justify-between pr-2 text-xs text-gray-600">
              <span>{maxParticipation}</span>
              <span>{Math.floor(maxParticipation * 0.75)}</span>
              <span>{Math.floor(maxParticipation * 0.5)}</span>
              <span>{Math.floor(maxParticipation * 0.25)}</span>
              <span>0</span>
            </div>
            <div className="flex-1 flex items-end justify-between h-full">
              {participationData.map((data, index) => (
                <div key={index} className="flex flex-col items-center w-full">
                  <div className="w-full flex justify-center">
                    <div 
                      className="w-16 bg-primary-500 hover:bg-primary-600 transition-all duration-300 rounded-t"
                      style={{ height: `${(data.count / maxParticipation) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-gray-600 mt-2">{data.month}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Students Table */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Registered Students</h2>
          <Link to="/dashboard/students" className="text-primary-600 hover:text-primary-700 flex items-center">
            View All <ChevronRight size={16} />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-2 text-gray-600">Name</th>
                <th className="text-left py-3 px-2 text-gray-600">Email</th>
                <th className="text-left py-3 px-2 text-gray-600">Applied Opportunities</th>
                <th className="text-left py-3 px-2 text-gray-600">Completed</th>
              </tr>
            </thead>
            <tbody>
              {institutionStudents.map((student) => (
                <tr key={student.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-2 font-medium">{student.name}</td>
                  <td className="py-3 px-2 text-gray-700">{student.email}</td>
                  <td className="py-3 px-2 text-gray-700">{student.appliedOpportunities?.length || 0}</td>
                  <td className="py-3 px-2 text-gray-700">{student.completedOpportunities?.length || 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Partner NGOs */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Partner NGOs</h2>
          <Link to="/directory/ngos" className="text-primary-600 hover:text-primary-700 flex items-center">
            View All <ChevronRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockNGOs.slice(0, 3).map((ngo) => (
            <div key={ngo.id} className="border rounded-lg p-4 hover:shadow-md transition duration-300">
              <div className="flex items-center mb-3">
                {ngo.profilePicture ? (
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
                    <img 
                      src={ngo.profilePicture} 
                      alt={ngo.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <span className="text-xl font-bold text-primary-600">{ngo.name.charAt(0)}</span>
                  </div>
                )}
                <div>
                  <h3 className="font-bold text-gray-800">{ngo.name}</h3>
                  <p className="text-gray-600 text-sm">{ngo.location}</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-3 line-clamp-2">{ngo.description}</p>
              <Link 
                to={`/directory/ngos/${ngo.id}`} 
                className="text-primary-600 hover:text-primary-700 text-sm font-medium"
              >
                View Profile
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default InstitutionDashboard;