import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Briefcase, 
  Award, 
  Clock, 
  CheckCircle, 
  BarChart2, 
  ChevronRight 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Student } from '../../types';
import { useOpportunities } from '../../context/OpportunityContext';
import { mockNGOs } from '../../data/mockData';

const StudentDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const student = currentUser as Student;
  const { opportunities, getApplicationsByStudentId } = useOpportunities();
  
  const studentApplications = getApplicationsByStudentId(student.id);
  
  // Filter opportunities that match student's preferences and are from Indian NGOs
  const recommendedOpportunities = opportunities
    .filter(opp => {
      // Only show opportunities from Indian NGOs
      const ngo = mockNGOs.find(n => n.id === opp.ngoId);
      if (!ngo) return false;
      
      // If student has preferences, filter by them
      if (!student.preferences || student.preferences.length === 0) return true;
      return opp.skills.some(skill => 
        student.preferences?.includes(skill)
      );
    })
    .slice(0, 3);

  // Filter NGOs based on student preferences and only show Indian NGOs
  const recommendedNGOs = mockNGOs
    .filter(ngo => {
      // All NGOs in mockData are already Indian, but we can add additional filtering
      if (!student.preferences || student.preferences.length === 0) return true;
      
      // Find opportunities posted by this NGO
      const ngoOpportunities = opportunities.filter(opp => opp.ngoId === ngo.id);
      
      // Check if any of the NGO's opportunities match student preferences
      return ngoOpportunities.some(opp => 
        opp.skills.some(skill => student.preferences?.includes(skill))
      );
    })
    .slice(0, 3);

  const applicationStats = {
    pending: studentApplications.filter(app => app.status === 'pending').length,
    accepted: studentApplications.filter(app => app.status === 'accepted').length,
    completed: student.completedOpportunities?.length || 0,
  };

  // Mock data for the impact graph
  const impactData = [
    { month: 'Jan', hours: 0 },
    { month: 'Feb', hours: 0 },
    { month: 'Mar', hours: 5 },
    { month: 'Apr', hours: 12 },
    { month: 'May', hours: 8 },
    { month: 'Jun', hours: 15 },
  ];

  const maxHours = Math.max(...impactData.map(d => d.hours));

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Welcome, {student.name}!</h1>
        <p className="text-gray-600">Track your applications, impact, and find new opportunities with Indian NGOs.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Stats Cards */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Applications</p>
              <h3 className="text-3xl font-bold text-gray-800">{studentApplications.length}</h3>
            </div>
            <div className="bg-primary-100 p-3 rounded-full">
              <Briefcase className="text-primary-600" size={24} />
            </div>
          </div>
          <div className="mt-4 flex space-x-4">
            <div className="flex items-center">
              <Clock size={16} className="text-gray-400 mr-1" />
              <span className="text-sm text-gray-600">{applicationStats.pending} Pending</span>
            </div>
            <div className="flex items-center">
              <CheckCircle size={16} className="text-secondary-500 mr-1" />
              <span className="text-sm text-gray-600">{applicationStats.accepted} Accepted</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Completed</p>
              <h3 className="text-3xl font-bold text-gray-800">{applicationStats.completed}</h3>
            </div>
            <div className="bg-secondary-100 p-3 rounded-full">
              <Award className="text-secondary-600" size={24} />
            </div>
          </div>
          <div className="mt-4">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-secondary-500 rounded-full" 
                style={{ width: `${(applicationStats.completed / 10) * 100}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-600 mt-1">{applicationStats.completed}/10 towards next badge</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-600 mb-1">Impact Hours</p>
              <h3 className="text-3xl font-bold text-gray-800">40</h3>
            </div>
            <div className="bg-accent-100 p-3 rounded-full">
              <BarChart2 className="text-accent-600" size={24} />
            </div>
          </div>
          <div className="mt-4 flex justify-between h-16">
            {impactData.map((data, index) => (
              <div key={index} className="flex flex-col items-center justify-end flex-1">
                <div 
                  className="w-full max-w-[20px] bg-accent-500 rounded-t-sm"
                  style={{ 
                    height: data.hours > 0 ? `${(data.hours / maxHours) * 100}%` : '2px',
                    opacity: data.hours > 0 ? 1 : 0.3
                  }}
                ></div>
                <span className="text-xs text-gray-600 mt-1">{data.month}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Applications */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Recent Applications</h2>
          <Link to="/dashboard/applications" className="text-primary-600 hover:text-primary-700 flex items-center">
            View All <ChevronRight size={16} />
          </Link>
        </div>

        {studentApplications.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2 text-gray-600">Opportunity</th>
                  <th className="text-left py-3 px-2 text-gray-600">NGO</th>
                  <th className="text-left py-3 px-2 text-gray-600">Applied On</th>
                  <th className="text-left py-3 px-2 text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {studentApplications.slice(0, 3).map((application) => {
                  const opportunity = opportunities.find(opp => opp.id === application.opportunityId);
                  
                  return (
                    <tr key={application.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-2">
                        <Link to={`/opportunities/${application.opportunityId}`} className="text-primary-600 hover:text-primary-700">
                          {opportunity?.title || 'Unknown Opportunity'}
                        </Link>
                      </td>
                      <td className="py-3 px-2 text-gray-700">{opportunity?.ngoName || 'Unknown NGO'}</td>
                      <td className="py-3 px-2 text-gray-700">{new Date(application.createdAt).toLocaleDateString()}</td>
                      <td className="py-3 px-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          application.status === 'accepted' ? 'bg-green-100 text-green-800' :
                          application.status === 'rejected' ? 'bg-red-100 text-red-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600 mb-4">You haven't applied to any opportunities yet.</p>
            <Link 
              to="/opportunities" 
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md transition duration-300"
            >
              Browse Opportunities
            </Link>
          </div>
        )}
      </div>

      {/* Recommended Opportunities */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Recommended Opportunities</h2>
          <Link to="/opportunities" className="text-primary-600 hover:text-primary-700 flex items-center">
            View All <ChevronRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recommendedOpportunities.map((opportunity) => (
            <div key={opportunity.id} className="border rounded-lg p-4 hover:shadow-md transition duration-300">
              <h3 className="font-bold text-gray-800 mb-1">{opportunity.title}</h3>
              <p className="text-secondary-600 text-sm mb-2">{opportunity.ngoName}</p>
              <p className="text-gray-600 text-sm mb-3 line-clamp-2">{opportunity.shortDescription || opportunity.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">Deadline: {new Date(opportunity.deadline).toLocaleDateString()}</span>
                <Link 
                  to={`/opportunities/${opportunity.id}`} 
                  className="text-primary-600 hover:text-primary-700 text-sm font-medium"
                >
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended NGOs */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">NGOs Matching Your Interests</h2>
          <Link to="/directory" className="text-primary-600 hover:text-primary-700 flex items-center">
            View All <ChevronRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recommendedNGOs.map((ngo) => (
            <div key={ngo.id} className="border rounded-lg p-4 hover:shadow-md transition duration-300">
              <div className="flex items-center mb-3">
                {ngo.profilePicture ? (
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
                    <img 
                      src={ngo.profilePicture} 
                      alt={ngo.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <span className="text-xl font-bold text-primary-600">{ngo.name.charAt(0)}</span>
                  </div>
                )}
                <div>
                  <h3 className="font-bold text-gray-800">{ngo.name}</h3>
                  <p className="text-gray-600 text-sm">{ngo.location}</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-3 line-clamp-2">{ngo.description}</p>
              <Link 
                to={`/directory/ngos/${ngo.id}`} 
                className="text-primary-600 hover:text-primary-700 text-sm font-medium"
              >
                View Profile
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;