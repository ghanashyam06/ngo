import React from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Clock, Briefcase, Building, Users, ArrowLeft } from 'lucide-react';
import { useOpportunities } from '../../context/OpportunityContext';
import { useAuth } from '../../context/AuthContext';

const OpportunityDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getOpportunityById } = useOpportunities();
  const { currentUser } = useAuth();
  
  const opportunity = getOpportunityById(id || '');

  if (!opportunity) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Opportunity Not Found</h2>
          <p className="text-gray-600 mb-6">The opportunity you're looking for doesn't exist or has been removed.</p>
          <Link 
            to="/opportunities" 
            className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-md transition duration-300"
          >
            Browse Opportunities
          </Link>
        </div>
      </div>
    );
  }

  const isStudent = currentUser?.role === 'student';
  const hasApplied = isStudent && opportunity.applicants?.includes(currentUser.id);

  return (
    <div className="container mx-auto px-4 py-8">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-primary-600 hover:text-primary-700 mb-6"
      >
        <ArrowLeft size={20} className="mr-1" /> Back
      </button>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {/* Header */}
        <div className="bg-primary-600 text-white p-8">
          <h1 className="text-3xl font-bold mb-2">{opportunity.title}</h1>
          <div className="flex items-center mb-4">
            <Building size={20} className="mr-2" />
            <span className="font-medium">{opportunity.ngoName}</span>
          </div>
          
          <div className="flex flex-wrap gap-4 text-primary-100">
            <div className="flex items-center">
              <MapPin size={18} className="mr-1" />
              <span>{opportunity.location}</span>
            </div>
            <div className="flex items-center">
              <Clock size={18} className="mr-1" />
              <span>{opportunity.duration}</span>
            </div>
            <div className="flex items-center">
              <Calendar size={18} className="mr-1" />
              <span>Deadline: {new Date(opportunity.deadline).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center">
              <Users size={18} className="mr-1" />
              <span>{opportunity.applicants?.length || 0} Applicants</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-800 mb-4">Description</h2>
                <p className="text-gray-700 whitespace-pre-line">{opportunity.description}</p>
              </div>

              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-800 mb-4">Requirements</h2>
                <p className="text-gray-700 whitespace-pre-line">{opportunity.requirements}</p>
              </div>

              <div>
                <h2 className="text-xl font-bold text-gray-800 mb-4">Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {opportunity.skills.map((skill, index) => (
                    <span 
                      key={index} 
                      className="bg-primary-100 text-primary-600 px-3 py-1 rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div>
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Overview</h3>
                
                <div className="space-y-4">
                  <div>
                    <div className="text-gray-600 mb-1">Position Type</div>
                    <div className="font-medium flex items-center">
                      <Briefcase size={18} className="text-primary-600 mr-2" />
                      Internship / Volunteer
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-gray-600 mb-1">Location</div>
                    <div className="font-medium flex items-center">
                      <MapPin size={18} className="text-primary-600 mr-2" />
                      {opportunity.location}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-gray-600 mb-1">Duration</div>
                    <div className="font-medium flex items-center">
                      <Clock size={18} className="text-primary-600 mr-2" />
                      {opportunity.duration}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-gray-600 mb-1">Deadline</div>
                    <div className="font-medium flex items-center">
                      <Calendar size={18} className="text-primary-600 mr-2" />
                      {new Date(opportunity.deadline).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </div>

              {isStudent && (
                <div className="text-center">
                  {hasApplied ? (
                    <div className="bg-green-100 text-green-700 p-4 rounded-lg">
                      <p className="font-medium">You have already applied for this opportunity.</p>
                    </div>
                  ) : (
                    <Link 
                      to={`/opportunities/${opportunity.id}/apply`} 
                      className="bg-accent-500 hover:bg-accent-600 text-white px-6 py-3 rounded-md transition duration-300 inline-block w-full"
                    >
                      Apply Now
                    </Link>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OpportunityDetail;