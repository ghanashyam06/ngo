import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useOpportunities } from '../../context/OpportunityContext';
import { useAuth } from '../../context/AuthContext';
import { Student } from '../../types';

const OpportunityApplication: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getOpportunityById, applyToOpportunity } = useOpportunities();
  const { currentUser } = useAuth();
  const student = currentUser as Student;
  
  const opportunity = getOpportunityById(id || '');

  const [formData, setFormData] = useState({
    duration: opportunity?.duration || '',
    preferredLocation: opportunity?.location || '',
    coverLetter: '',
    agreement: false,
  });

  const [errors, setErrors] = useState({
    duration: '',
    preferredLocation: '',
    coverLetter: '',
    agreement: '',
  });

  if (!opportunity) {
    navigate('/opportunities');
    return null;
  }

  if (!currentUser || currentUser.role !== 'student') {
    navigate(`/opportunities/${id}`);
    return null;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    // Clear error when field is edited
    setErrors({
      ...errors,
      [name]: '',
    });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked,
    });
    // Clear error when field is edited
    setErrors({
      ...errors,
      [name]: '',
    });
  };

  const validate = () => {
    const newErrors = {
      duration: '',
      preferredLocation: '',
      coverLetter: '',
      agreement: '',
    };
    let isValid = true;

    if (!formData.duration) {
      newErrors.duration = 'Duration is required';
      isValid = false;
    }

    if (!formData.preferredLocation) {
      newErrors.preferredLocation = 'Preferred location is required';
      isValid = false;
    }

    if (formData.coverLetter.length < 50) {
      newErrors.coverLetter = 'Cover letter must be at least 50 characters';
      isValid = false;
    }

    if (!formData.agreement) {
      newErrors.agreement = 'You must agree to the terms';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) {
      return;
    }

    // Submit application
    applyToOpportunity(
      opportunity.id,
      student.id,
      student.name,
      formData.duration,
      formData.preferredLocation
    );

    // Navigate to success page or dashboard
    navigate(`/opportunities/${id}/apply/success`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-primary-600 hover:text-primary-700 mb-6"
      >
        <ArrowLeft size={20} className="mr-1" /> Back to Opportunity
      </button>

      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-primary-600 text-white p-6">
            <h1 className="text-2xl font-bold">Apply for Opportunity</h1>
            <p className="text-primary-100 mt-2">{opportunity.title} at {opportunity.ngoName}</p>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="mb-6">
              <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
                Duration*
              </label>
              <select
                id="duration"
                name="duration"
                value={formData.duration}
                onChange={handleChange}
                className={`block w-full px-3 py-2 border ${errors.duration ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
              >
                <option value="">Select Duration</option>
                <option value="1 month">1 month</option>
                <option value="2 months">2 months</option>
                <option value="3 months">3 months</option>
                <option value="4 months">4 months</option>
                <option value="6 months">6 months</option>
                <option value="Custom">Custom</option>
              </select>
              {errors.duration && <p className="mt-1 text-sm text-red-600">{errors.duration}</p>}
            </div>

            <div className="mb-6">
              <label htmlFor="preferredLocation" className="block text-sm font-medium text-gray-700 mb-1">
                Preferred Location*
              </label>
              <select
                id="preferredLocation"
                name="preferredLocation"
                value={formData.preferredLocation}
                onChange={handleChange}
                className={`block w-full px-3 py-2 border ${errors.preferredLocation ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
              >
                <option value="">Select Location</option>
                <option value={opportunity.location}>{opportunity.location}</option>
                <option value="Remote">Remote</option>
                <option value="Hybrid">Hybrid</option>
              </select>
              {errors.preferredLocation && <p className="mt-1 text-sm text-red-600">{errors.preferredLocation}</p>}
            </div>

            <div className="mb-6">
              <label htmlFor="coverLetter" className="block text-sm font-medium text-gray-700 mb-1">
                Cover Letter / Statement of Interest*
              </label>
              <textarea
                id="coverLetter"
                name="coverLetter"
                rows={6}
                value={formData.coverLetter}
                onChange={handleChange}
                placeholder="Explain why you are interested in this opportunity and how your skills and experience make you a good fit..."
                className={`block w-full px-3 py-2 border ${errors.coverLetter ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
              />
              <p className="mt-1 text-sm text-gray-500">
                {formData.coverLetter.length} / 500 characters (minimum 50)
              </p>
              {errors.coverLetter && <p className="mt-1 text-sm text-red-600">{errors.coverLetter}</p>}
            </div>

            <div className="mb-6">
              <div className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id="agreement"
                    name="agreement"
                    type="checkbox"
                    checked={formData.agreement}
                    onChange={handleCheckboxChange}
                    className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                  />
                </div>
                <div className="ml-3">
                  <label htmlFor="agreement" className="text-sm text-gray-700">
                    I confirm that all information provided is accurate and I understand that this application is subject to review by the NGO.
                  </label>
                  {errors.agreement && <p className="mt-1 text-sm text-red-600">{errors.agreement}</p>}
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => navigate(-1)}
                className="mr-4 px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Submit Application
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default OpportunityApplication;