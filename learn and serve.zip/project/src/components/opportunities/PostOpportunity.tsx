import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus } from 'lucide-react';
import { useOpportunities } from '../../context/OpportunityContext';
import { useAuth } from '../../context/AuthContext';
import { NGO } from '../../types';
import { indianCities } from '../../data/indianCities';

const PostOpportunity: React.FC = () => {
  const navigate = useNavigate();
  const { addOpportunity } = useOpportunities();
  const { currentUser } = useAuth();
  const ngo = currentUser as NGO;

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    location: '',
    duration: '',
    skills: [] as string[],
    requirements: '',
    deadline: '',
  });

  const [errors, setErrors] = useState({
    title: '',
    description: '',
    shortDescription: '',
    location: '',
    duration: '',
    skills: '',
    requirements: '',
    deadline: '',
  });

  const [newSkill, setNewSkill] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!currentUser || currentUser.role !== 'ngo') {
    navigate('/dashboard');
    return null;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    // Clear error when field is edited
    if (errors[name as keyof typeof errors]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({
        ...formData,
        skills: [...formData.skills, newSkill.trim()],
      });
      setNewSkill('');
      setErrors({
        ...errors,
        skills: '',
      });
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter(skill => skill !== skillToRemove),
    });
  };

  const validate = () => {
    const newErrors = {
      title: '',
      description: '',
      shortDescription: '',
      location: '',
      duration: '',
      skills: '',
      requirements: '',
      deadline: '',
    };
    let isValid = true;

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
      isValid = false;
    }

    if (!formData.shortDescription.trim()) {
      newErrors.shortDescription = 'Short description is required';
      isValid = false;
    } else if (formData.shortDescription.length < 50) {
      newErrors.shortDescription = 'Short description must be at least 50 characters (4-5 lines)';
      isValid = false;
    } else if (formData.shortDescription.length > 300) {
      newErrors.shortDescription = 'Short description must not exceed 300 characters';
      isValid = false;
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Detailed description is required';
      isValid = false;
    } else if (formData.description.length < 100) {
      newErrors.description = 'Detailed description must be at least 100 characters';
      isValid = false;
    }

    if (!formData.location) {
      newErrors.location = 'Location is required';
      isValid = false;
    }

    if (!formData.duration) {
      newErrors.duration = 'Duration is required';
      isValid = false;
    }

    if (formData.skills.length === 0) {
      newErrors.skills = 'At least one skill is required';
      isValid = false;
    }

    if (!formData.requirements.trim()) {
      newErrors.requirements = 'Requirements are required';
      isValid = false;
    }

    if (!formData.deadline) {
      newErrors.deadline = 'Deadline is required';
      isValid = false;
    } else {
      const deadlineDate = new Date(formData.deadline);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (deadlineDate <= today) {
        newErrors.deadline = 'Deadline must be in the future';
        isValid = false;
      }
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      addOpportunity({
        title: formData.title,
        description: formData.description,
        shortDescription: formData.shortDescription,
        ngoId: ngo.id,
        ngoName: ngo.name,
        location: formData.location,
        duration: formData.duration,
        skills: formData.skills,
        requirements: formData.requirements,
        deadline: formData.deadline,
        status: 'open',
      });

      navigate('/dashboard');
    } catch (error) {
      console.error('Error posting opportunity:', error);
      setIsSubmitting(false);
    }
  };

  const durations = [
    '1 month',
    '2 months',
    '3 months',
    '4 months',
    '6 months',
    '1 year',
    'Flexible',
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <button 
        onClick={() => navigate('/dashboard')} 
        className="flex items-center text-primary-600 hover:text-primary-700 mb-6"
      >
        <ArrowLeft size={20} className="mr-1" /> Back to Dashboard
      </button>

      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-primary-600 text-white p-6">
            <h1 className="text-2xl font-bold">Post New Opportunity</h1>
            <p className="text-primary-100 mt-2">Create an internship or volunteer opportunity for students</p>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Title */}
              <div className="lg:col-span-2">
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Opportunity Title*
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="e.g., Environmental Conservation Intern"
                  className={`block w-full px-3 py-2 border ${errors.title ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title}</p>}
              </div>

              {/* Short Description */}
              <div className="lg:col-span-2">
                <label htmlFor="shortDescription" className="block text-sm font-medium text-gray-700 mb-1">
                  Short Description (4-5 lines)*
                </label>
                <textarea
                  id="shortDescription"
                  name="shortDescription"
                  rows={4}
                  value={formData.shortDescription}
                  onChange={handleChange}
                  placeholder="Provide a brief 4-5 line description of the internship that will be displayed on opportunity cards..."
                  className={`block w-full px-3 py-2 border ${errors.shortDescription ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                <p className="mt-1 text-sm text-gray-500">
                  {formData.shortDescription.length}/300 characters (minimum 50)
                </p>
                {errors.shortDescription && <p className="mt-1 text-sm text-red-600">{errors.shortDescription}</p>}
              </div>

              {/* Detailed Description */}
              <div className="lg:col-span-2">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Detailed Description*
                </label>
                <textarea
                  id="description"
                  name="description"
                  rows={6}
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Provide a comprehensive description of the opportunity, responsibilities, and what students will learn..."
                  className={`block w-full px-3 py-2 border ${errors.description ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.description && <p className="mt-1 text-sm text-red-600">{errors.description}</p>}
              </div>

              {/* Location */}
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                  Location*
                </label>
                <select
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.location ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                >
                  <option value="">Select Location</option>
                  {indianCities.map((city, index) => (
                    <option key={index} value={city}>{city}</option>
                  ))}
                  <option value="Remote">Remote</option>
                  <option value="Hybrid">Hybrid</option>
                </select>
                {errors.location && <p className="mt-1 text-sm text-red-600">{errors.location}</p>}
              </div>

              {/* Duration */}
              <div>
                <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
                  Duration*
                </label>
                <select
                  id="duration"
                  name="duration"
                  value={formData.duration}
                  onChange={handleChange}
                  className={`block w-full px-3 py-2 border ${errors.duration ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                >
                  <option value="">Select Duration</option>
                  {durations.map((duration, index) => (
                    <option key={index} value={duration}>{duration}</option>
                  ))}
                </select>
                {errors.duration && <p className="mt-1 text-sm text-red-600">{errors.duration}</p>}
              </div>

              {/* Skills */}
              <div className="lg:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Required Skills*
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    placeholder="Add a skill"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                  />
                  <button
                    type="button"
                    onClick={addSkill}
                    className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md transition duration-300 flex items-center"
                  >
                    <Plus size={16} className="mr-1" />
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mb-2">
                  {formData.skills.map((skill, index) => (
                    <span 
                      key={index} 
                      className="bg-primary-100 text-primary-600 px-3 py-1 rounded-full text-sm flex items-center"
                    >
                      {skill}
                      <button
                        type="button"
                        onClick={() => removeSkill(skill)}
                        className="ml-2 text-primary-600 hover:text-primary-800"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
                {errors.skills && <p className="mt-1 text-sm text-red-600">{errors.skills}</p>}
              </div>

              {/* Requirements */}
              <div className="lg:col-span-2">
                <label htmlFor="requirements" className="block text-sm font-medium text-gray-700 mb-1">
                  Requirements*
                </label>
                <textarea
                  id="requirements"
                  name="requirements"
                  rows={4}
                  value={formData.requirements}
                  onChange={handleChange}
                  placeholder="List the requirements, qualifications, and expectations for applicants..."
                  className={`block w-full px-3 py-2 border ${errors.requirements ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.requirements && <p className="mt-1 text-sm text-red-600">{errors.requirements}</p>}
              </div>

              {/* Deadline */}
              <div>
                <label htmlFor="deadline" className="block text-sm font-medium text-gray-700 mb-1">
                  Application Deadline*
                </label>
                <input
                  type="date"
                  id="deadline"
                  name="deadline"
                  value={formData.deadline}
                  onChange={handleChange}
                  min={new Date(Date.now() + 86400000).toISOString().split('T')[0]} // Tomorrow
                  className={`block w-full px-3 py-2 border ${errors.deadline ? 'border-red-500' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
                {errors.deadline && <p className="mt-1 text-sm text-red-600">{errors.deadline}</p>}
              </div>
            </div>

            <div className="mt-8 flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="px-6 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
              >
                {isSubmitting ? 'Posting...' : 'Post Opportunity'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PostOpportunity;