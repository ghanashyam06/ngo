import React, { useState } from 'react';
import { Search, Filter, X } from 'lucide-react';
import OpportunityCard from '../common/OpportunityCard';
import { useOpportunities } from '../../context/OpportunityContext';

const OpportunityList: React.FC = () => {
  const { opportunities } = useOpportunities();
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    location: '',
    duration: '',
    skills: [] as string[],
  });
  const [showFilters, setShowFilters] = useState(false);

  // Extract unique locations and durations for filter options
  const locations = Array.from(new Set(opportunities.map(opp => opp.location)));
  const durations = Array.from(new Set(opportunities.map(opp => opp.duration)));
  
  // Extract all unique skills for filter options
  const allSkills = Array.from(
    new Set(opportunities.flatMap(opp => opp.skills))
  );

  // Filter opportunities based on search and filters
  const filteredOpportunities = opportunities.filter(opportunity => {
    // Search term filter
    const matchesSearch = 
      searchTerm === '' ||
      opportunity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      opportunity.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      opportunity.ngoName.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Location filter
    const matchesLocation = 
      filters.location === '' || 
      opportunity.location === filters.location;
    
    // Duration filter
    const matchesDuration = 
      filters.duration === '' || 
      opportunity.duration === filters.duration;
    
    // Skills filter
    const matchesSkills = 
      filters.skills.length === 0 || 
      filters.skills.some(skill => opportunity.skills.includes(skill));
    
    return matchesSearch && matchesLocation && matchesDuration && matchesSkills;
  });

  const handleSkillToggle = (skill: string) => {
    setFilters(prev => {
      const skills = prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill];
      
      return { ...prev, skills };
    });
  };

  const resetFilters = () => {
    setFilters({
      location: '',
      duration: '',
      skills: [],
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Browse Opportunities</h1>
      
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Search opportunities, skills, or NGOs..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          
          {/* Filter Toggle Button */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="bg-white border border-gray-300 rounded-lg px-4 py-3 flex items-center justify-center text-gray-700 hover:bg-gray-50 shadow-sm md:w-auto w-full"
          >
            <Filter className="h-5 w-5 mr-2" />
            Filters
            {(filters.location || filters.duration || filters.skills.length > 0) && (
              <span className="ml-2 bg-primary-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                {(!!filters.location ? 1 : 0) + 
                 (!!filters.duration ? 1 : 0) + 
                 (filters.skills.length > 0 ? 1 : 0)}
              </span>
            )}
          </button>
        </div>
        
        {/* Filters Panel */}
        {showFilters && (
          <div className="mt-4 bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-800">Filter Opportunities</h3>
              <button 
                onClick={resetFilters}
                className="text-primary-600 hover:text-primary-700 text-sm font-medium"
              >
                Reset All
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Location Filter */}
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                  Location
                </label>
                <select
                  id="location"
                  className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  value={filters.location}
                  onChange={e => setFilters({ ...filters, location: e.target.value })}
                >
                  <option value="">All Locations</option>
                  {locations.map((location, index) => (
                    <option key={index} value={location}>{location}</option>
                  ))}
                </select>
              </div>
              
              {/* Duration Filter */}
              <div>
                <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
                  Duration
                </label>
                <select
                  id="duration"
                  className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  value={filters.duration}
                  onChange={e => setFilters({ ...filters, duration: e.target.value })}
                >
                  <option value="">All Durations</option>
                  {durations.map((duration, index) => (
                    <option key={index} value={duration}>{duration}</option>
                  ))}
                </select>
              </div>
              
              {/* Status Filter - left empty for future expansion */}
              <div></div>
            </div>
            
            {/* Skills Filter */}
            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Skills
              </label>
              <div className="flex flex-wrap gap-2">
                {allSkills.map((skill, index) => (
                  <button
                    key={index}
                    onClick={() => handleSkillToggle(skill)}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      filters.skills.includes(skill)
                        ? 'bg-primary-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {skill}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Active Filters */}
            {(filters.location || filters.duration || filters.skills.length > 0) && (
              <div className="mt-6">
                <div className="text-sm font-medium text-gray-700 mb-2">Active Filters:</div>
                <div className="flex flex-wrap gap-2">
                  {filters.location && (
                    <div className="bg-primary-100 text-primary-700 px-3 py-1 rounded-full text-sm font-medium flex items-center">
                      Location: {filters.location}
                      <button 
                        onClick={() => setFilters({ ...filters, location: '' })}
                        className="ml-1 text-primary-700 hover:text-primary-800"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  )}
                  
                  {filters.duration && (
                    <div className="bg-primary-100 text-primary-700 px-3 py-1 rounded-full text-sm font-medium flex items-center">
                      Duration: {filters.duration}
                      <button 
                        onClick={() => setFilters({ ...filters, duration: '' })}
                        className="ml-1 text-primary-700 hover:text-primary-800"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  )}
                  
                  {filters.skills.map((skill, index) => (
                    <div 
                      key={index} 
                      className="bg-primary-100 text-primary-700 px-3 py-1 rounded-full text-sm font-medium flex items-center"
                    >
                      Skill: {skill}
                      <button 
                        onClick={() => handleSkillToggle(skill)}
                        className="ml-1 text-primary-700 hover:text-primary-800"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Results */}
      <div>
        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-800">
            {filteredOpportunities.length} {filteredOpportunities.length === 1 ? 'Opportunity' : 'Opportunities'} Found
          </h2>
          <div className="text-gray-600">
            Showing {filteredOpportunities.length} of {opportunities.length}
          </div>
        </div>
        
        {filteredOpportunities.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredOpportunities.map(opportunity => (
              <OpportunityCard 
                key={opportunity.id} 
                opportunity={opportunity} 
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <h3 className="text-xl font-bold text-gray-800 mb-2">No Opportunities Found</h3>
            <p className="text-gray-600 mb-4">
              We couldn't find any opportunities matching your criteria. Try adjusting your filters.
            </p>
            <button 
              onClick={resetFilters}
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md transition duration-300"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default OpportunityList;