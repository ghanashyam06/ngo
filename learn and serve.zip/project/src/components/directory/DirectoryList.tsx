import React, { useState } from 'react';
import { Search, Filter, Building, Users } from 'lucide-react';
import { mockNGOs, mockInstitutions } from '../../data/mockData';
import NGOCard from '../common/NGOCard';
import InstitutionCard from '../common/InstitutionCard';

type DirectoryType = 'ngos' | 'institutions';

const DirectoryList: React.FC = () => {
  const [directoryType, setDirectoryType] = useState<DirectoryType>('ngos');
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('');

  const handleTypeChange = (type: DirectoryType) => {
    setDirectoryType(type);
    setSearchTerm('');
    setLocationFilter('');
  };

  // Filter NGOs based on search and location
  const filteredNGOs = mockNGOs.filter(ngo => {
    const matchesSearch = 
      searchTerm === '' ||
      ngo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ngo.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesLocation = 
      locationFilter === '' || 
      ngo.location.includes(locationFilter);
    
    return matchesSearch && matchesLocation;
  });

  // Filter institutions based on search and location
  const filteredInstitutions = mockInstitutions.filter(institution => {
    const matchesSearch = 
      searchTerm === '' ||
      institution.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      institution.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesLocation = 
      locationFilter === '' || 
      institution.location.includes(locationFilter);
    
    return matchesSearch && matchesLocation;
  });

  // Get unique locations based on current directory type
  const locations = directoryType === 'ngos'
    ? Array.from(new Set(mockNGOs.map(ngo => ngo.location)))
    : Array.from(new Set(mockInstitutions.map(inst => inst.location)));

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Directory</h1>
      
      {/* Directory Type Selector */}
      <div className="flex mb-8">
        <button
          className={`flex items-center justify-center px-6 py-3 rounded-l-lg font-medium ${
            directoryType === 'ngos'
              ? 'bg-primary-600 text-white'
              : 'bg-white text-gray-700 hover:bg-gray-50'
          }`}
          onClick={() => handleTypeChange('ngos')}
        >
          <Building className="h-5 w-5 mr-2" />
          NGOs
        </button>
        <button
          className={`flex items-center justify-center px-6 py-3 rounded-r-lg font-medium ${
            directoryType === 'institutions'
              ? 'bg-primary-600 text-white'
              : 'bg-white text-gray-700 hover:bg-gray-50'
          }`}
          onClick={() => handleTypeChange('institutions')}
        >
          <Users className="h-5 w-5 mr-2" />
          Educational Institutions
        </button>
      </div>
      
      {/* Search and Filter */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder={`Search ${directoryType === 'ngos' ? 'NGOs' : 'institutions'}...`}
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          
          {/* Location Filter */}
          <div className="md:w-64">
            <select
              className="block w-full pl-3 pr-10 py-3 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={locationFilter}
              onChange={e => setLocationFilter(e.target.value)}
            >
              <option value="">All Locations</option>
              {locations.map((location, index) => (
                <option key={index} value={location}>{location}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {/* Results */}
      <div>
        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-800">
            {directoryType === 'ngos' 
              ? `${filteredNGOs.length} NGOs Found`
              : `${filteredInstitutions.length} Institutions Found`
            }
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {directoryType === 'ngos' ? (
            filteredNGOs.length > 0 ? (
              filteredNGOs.map(ngo => (
                <NGOCard key={ngo.id} ngo={ngo} />
              ))
            ) : (
              <div className="col-span-3 bg-white rounded-lg shadow-md p-8 text-center">
                <h3 className="text-xl font-bold text-gray-800 mb-2">No NGOs Found</h3>
                <p className="text-gray-600">
                  Try adjusting your search or filter criteria.
                </p>
              </div>
            )
          ) : (
            filteredInstitutions.length > 0 ? (
              filteredInstitutions.map(institution => (
                <InstitutionCard key={institution.id} institution={institution} />
              ))
            ) : (
              <div className="col-span-3 bg-white rounded-lg shadow-md p-8 text-center">
                <h3 className="text-xl font-bold text-gray-800 mb-2">No Institutions Found</h3>
                <p className="text-gray-600">
                  Try adjusting your search or filter criteria.
                </p>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default DirectoryList;