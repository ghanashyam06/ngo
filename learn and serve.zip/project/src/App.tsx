import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import OpportunitiesPage from './pages/OpportunitiesPage';
import OpportunityDetailPage from './pages/OpportunityDetailPage';
import OpportunityApplicationPage from './pages/OpportunityApplicationPage';
import ApplicationSuccessPage from './pages/ApplicationSuccessPage';
import DirectoryPage from './pages/DirectoryPage';
import ContactPage from './pages/ContactPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import PostOpportunityPage from './pages/PostOpportunityPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/dashboard" element={<DashboardPage />} />
      <Route path="/opportunities" element={<OpportunitiesPage />} />
      <Route path="/opportunities/new" element={<PostOpportunityPage />} />
      <Route path="/opportunities/:id" element={<OpportunityDetailPage />} />
      <Route path="/opportunities/:id/apply" element={<OpportunityApplicationPage />} />
      <Route path="/opportunities/:id/apply/success" element={<ApplicationSuccessPage />} />
      <Route path="/directory" element={<DirectoryPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
    </Routes>
  );
}

export default App;