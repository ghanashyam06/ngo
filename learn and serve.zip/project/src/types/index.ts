export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'ngo' | 'institution';
  profilePicture?: string;
}

export interface Student extends User {
  role: 'student';
  institution: string;
  phoneNumber: string;
  preferences?: string[];
  skills?: string[];
  completedOpportunities?: Opportunity[];
  appliedOpportunities?: string[];
}

export interface NGO extends User {
  role: 'ngo';
  description: string;
  website?: string;
  location: string;
  phoneNumber: string;
  opportunities?: Opportunity[];
}

export interface Institution extends User {
  role: 'institution';
  description: string;
  website?: string;
  location: string;
  phoneNumber: string;
  students?: Student[];
}

export interface Opportunity {
  id: string;
  title: string;
  description: string;
  shortDescription?: string;
  ngoId: string;
  ngoName: string;
  location: string;
  duration: string;
  skills: string[];
  requirements: string;
  deadline: string;
  status: 'open' | 'closed';
  applicants?: string[];
  createdAt: string;
}

export interface Application {
  id: string;
  opportunityId: string;
  studentId: string;
  studentName: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  duration: string;
  preferredLocation: string;
}

export interface Quote {
  id: number;
  text: string;
  author: string;
}